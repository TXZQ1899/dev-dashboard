/* 图表与结构图渲染 —— 数据来源见报告第 03、07 节 */
(function () {
  'use strict';

  var INK = '#1a1f26';
  var MUTED = '#5b6672';
  var RULE = '#dde2e8';
  var SLOW = '#c2410c';
  var FAST = '#0f766e';
  var FONT = "'Instrument Sans', 'PingFang SC', 'Microsoft YaHei', sans-serif";

  function initThroughput() {
    var el = document.getElementById('chart-throughput');
    if (!el || !window.echarts) return;
    var chart = echarts.init(el, null, { renderer: 'canvas' });

    var rows = [
      { name: 'docker.1ms.run（镜像代理）', value: 3.5, tone: 'slow', note: '49.89 MB 层 · 24 分钟 5.24 MB' },
      { name: 'deb.debian.org（构建实况）', value: 27, tone: 'slow', note: '8790 kB / 326 s；apt 自报 27.4 kB/s' },
      { name: 'deb.debian.org（短窗口测速）', value: 73, tone: 'mid', note: '599 872 B / 8 007 ms，长传输会回落到 27 kB/s' },
      { name: 'mirrors.aliyun.com', value: 315, tone: 'fast', note: '2 637 588 B / 8 166 ms' },
      { name: 'mirrors.tuna.tsinghua.edu.cn', value: 6459, tone: 'fast', note: '8 790 394 B / 1 329 ms' }
    ];
    var TONE = { slow: SLOW, mid: '#9aa5b1', fast: FAST };

    chart.setOption({
      animationDuration: 700,
      grid: { left: 8, right: 78, top: 18, bottom: 40, containLabel: true },
      tooltip: {
        trigger: 'item',
        backgroundColor: '#ffffff',
        borderColor: RULE,
        borderWidth: 1,
        textStyle: { color: INK, fontFamily: FONT, fontSize: 12 },
        formatter: function (p) {
          var row = rows[p.dataIndex];
          return '<strong>' + row.name + '</strong><br/>' +
            row.value + ' KB/s<br/><span style="color:' + MUTED + '">' + row.note + '</span>';
        }
      },
      xAxis: {
        type: 'log',
        min: 1,
        max: 10000,
        name: 'KB/s（对数）',
        nameLocation: 'middle',
        nameGap: 28,
        nameTextStyle: { color: MUTED, fontSize: 11, fontFamily: FONT },
        axisLine: { lineStyle: { color: RULE } },
        axisTick: { show: false },
        splitLine: { lineStyle: { color: RULE, type: 'dashed' } },
        axisLabel: {
          color: MUTED,
          fontSize: 11,
          fontFamily: FONT,
          formatter: function (v) { return v >= 1000 ? (v / 1000) + 'k' : String(v); }
        }
      },
      yAxis: {
        type: 'category',
        data: rows.map(function (r) { return r.name; }),
        axisLine: { show: false },
        axisTick: { show: false },
        axisLabel: {
          color: INK,
          fontSize: 11.5,
          fontFamily: FONT,
          width: 230,
          overflow: 'break'
        }
      },
      series: [{
        type: 'bar',
        barWidth: 22,
        data: rows.map(function (r) {
          return {
            value: r.value,
            itemStyle: {
              color: TONE[r.tone] || FAST,
              borderRadius: [0, 3, 3, 0]
            }
          };
        }),
        label: {
          show: true,
          position: 'right',
          distance: 8,
          color: INK,
          fontSize: 11.5,
          fontFamily: FONT,
          fontWeight: 700,
          formatter: function (p) {
            return p.value >= 1000
              ? (p.value / 1000).toFixed(1) + ' MB/s'
              : p.value + ' KB/s';
          }
        }
      }]
    });

    window.addEventListener('resize', function () { chart.resize(); });
  }

  function initFlow() {
    var el = document.getElementById('flow');
    if (!el || !window.mermaid) return;

    mermaid.initialize({
      startOnLoad: false,
      securityLevel: 'loose',
      theme: 'base',
      fontFamily: FONT,
      themeVariables: {
        fontFamily: FONT,
        fontSize: '13px',
        lineColor: '#9aa5b1',
        textColor: INK,
        primaryColor: '#ffffff',
        primaryBorderColor: RULE,
        primaryTextColor: INK,
        tertiaryColor: '#f7f8fa'
      },
      flowchart: { curve: 'basis', nodeSpacing: 42, rankSpacing: 42, htmlLabels: true }
    });

    var src = [
      'flowchart TD',
      '  A["bash build.sh<br/>同步 collectors"] --> B["build 阶段<br/>npm ci（缓存命中）"]',
      '  B --> C["npm run build<br/>14.3 秒完成"]',
      '  C --> D["runtime 阶段"]',
      '  D -.-> E["拉取 node 基础镜像层<br/>docker.1ms.run"]',
      '  E -.-> E2["49.89 MB 层<br/>约 24 分钟仅 5.24 MB"]',
      '  D --> F["apt-get update<br/>deb.debian.org"]',
      '  F -.-> F2["bookworm/main Packages<br/>8790 kB · 停在此处"]',
      '  F2 -.-> G["apt-get install<br/>5 个 python 相关包"]',
      '  G --> H["COPY 构建产物 + collectors"]',
      '  H --> I["envscope:local"]',
      '  classDef stall fill:#fdf4ef,stroke:#c2410c,stroke-width:2px,color:#1a1f26;',
      '  classDef done fill:#f2f8f7,stroke:#0f766e,stroke-width:1.5px,color:#1a1f26;',
      '  classDef plain fill:#ffffff,stroke:#dde2e8,color:#1a1f26;',
      '  class E,E2,F,F2 stall;',
      '  class C,H,I done;',
      '  class A,B,D,G plain;'
    ].join('\n');

    // 用 mermaid.render 直接产出 SVG，避免自动扫描页面上的其它块
    mermaid.render('flow-svg', src).then(function (res) {
      el.innerHTML = res.svg;
      res.bindFunctions && res.bindFunctions(el);
    }).catch(function (err) {
      el.innerHTML = '<pre style="white-space:pre-wrap">' + String(err) + '</pre>';
    });
  }

  function boot() {
    initThroughput();
    initFlow();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
